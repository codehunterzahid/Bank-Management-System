#include<iostream>
#include<windows.h>
#include<cstring>
#include<fstream> // Added for file operations
using namespace std;

// Structure for book to store data
struct Book {
    string title, author, genre;
    int quantity;
    float price;
};

// Function prototypes
void showMenu();
void addBook(Book books[], int& totalBooks);
void displayBooks(const Book books[], int totalBooks);
void sellBook(Book books[], int totalBooks);
void deleteBook(Book books[], int& totalBooks);
void searchBook(const Book books[], int totalBooks);
void saveBookData(const Book books[], int totalBooks); // Added for saving book data
void loadBookData(Book books[], int& totalBooks);      // Added for loading book data
void exitProgram();

int main() {
    Book books[50];  // 50 Books Can be Store
    int totalBooks = 0;
    int choice;

    // Load book data from file at program start
    loadBookData(books, totalBooks);

    while (true) {
    cout << "\nBookshop Management System";
    cout << "\n--------------------------\n";
    cout << "\n1. Add Book\n";
    cout << "2. Display Books\n";
    cout << "3. Sell Book\n";
    cout << "4. Search for a Book\n";
    cout << "5. Delete Book\n";
    cout << "6. Exit\n";             // Updated menu option

    cout << "\nEnter your choice: ";
    cin >> choice;
    system("CLS");

    switch (choice) {
        case 1:
            addBook(books, totalBooks);
            break;

        case 2:
            displayBooks(books, totalBooks);
            break;

        case 3:
            sellBook(books, totalBooks);
            break;

        case 4:
            searchBook(books, totalBooks);
            break;

        case 5:
            deleteBook(books, totalBooks);
            break;

        case 6:
            // Save book data to file before exiting
            saveBookData(books, totalBooks);
            exitProgram();
            break;

        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}


// Function to add books to store
void addBook(Book books[], int& totalBooks) {
	
	system("CLS");
	
    cout << "\nEnter book details:\n\n";
    cout << "Title : ";
    cin.ignore();
    getline(cin, books[totalBooks].title);

    cout << "Author: ";
    getline(cin, books[totalBooks].author);

    cout << "Type : ";
    getline(cin, books[totalBooks].genre);

    cout << "Quantity : ";
    cin >> books[totalBooks].quantity;

    cout << "Price : ";
    cin >> books[totalBooks].price;

    totalBooks++;
    cout << "Book added successfully!\n";
}

// Function to Display books with all details
void displayBooks(const Book books[], int totalBooks) {
	
	system("CLS");
	
    if (totalBooks == 0) {
        cout << "\nNo books have been added yet.\n";
    } else {
        cout << "\nBook List:\n\n";
        for (int i = 0; i < totalBooks; i++) {
            cout << "Title: " << books[i].title << "\n";
            cout << "Author: " << books[i].author << "\n";
            cout << "Type: " << books[i].genre << "\n";
            cout << "Quantity: " << books[i].quantity << "\n";
            cout << "Price: $" << books[i].price << "\n\n";
        }
    }
}

// Sale book and reduce quantity of books
void sellBook(Book books[], int totalBooks) {
	
	system("CLS");
	
    string title;
    cout << "Enter the title of the book to sell: ";
    cin.ignore();
    getline(cin, title);

    for (int i = 0; i < totalBooks; i++) {
        if (title == books[i].title) {
            if (books[i].quantity > 0) {
                books[i].quantity--;
                cout << "Book sold successfully!\n";
            } else {
                cout << "Sorry, the book is out of stock.\n";
            }
            return;
        }
    }

    cout << "Book not found in the inventory.\n";
}

// to delete whole stock of books
void deleteBook(Book books[], int& totalBooks) {
	
	system("CLS");
	
    string title;
    cout << "Enter the title of the book to delete: ";
    cin.ignore();
    getline(cin, title);

    for (int i = 0; i < totalBooks; i++) {
        if (title == books[i].title) {
            for (int j = i; j < totalBooks - 1; j++) {
                books[j] = books[j + 1];
            }
            totalBooks--;
            cout << "Book deleted successfully!\n";
            return;
        }
    }

    cout << "Book not found in the inventory.\n";
}

// search for specific book 
void searchBook(const Book books[], int totalBooks) {
	
	system("CLS");
	
    string title;
    cout << "Enter the title of the book to search: ";
    cin.ignore();
    getline(cin, title);

    for (int i = 0; i < totalBooks; i++) {
        if (title == books[i].title) {
            cout << "\nBook Found:\n\n";
            cout << "Title: " << books[i].title << "\n";
            cout << "Author: " << books[i].author << "\n";
            cout << "Type: " << books[i].genre << "\n";
            cout << "Quantity: " << books[i].quantity << "\n";
            cout << "Price: $" << books[i].price << "\n";
            return;
        }
    }

    cout << "Book not found in the inventory.\n";
}


// Function to save books data to a file
void saveBookData(const Book books[], int totalBooks) {
    ofstream file("book_data.txt");
    if (file.is_open()) {
        file << totalBooks << endl;
        for (int i = 0; i < totalBooks; i++) {
            file << books[i].title << "|" << books[i].author << "|" << books[i].genre << "|"
                 << books[i].quantity << "|" << books[i].price << endl;
        }
        cout << "Book data saved successfully." << endl;
    } else {
        cerr << "Unable to open file for saving book data.\n";
    }
}

// Function to load books data from a file
void loadBookData(Book books[], int& totalBooks) {
    ifstream file("book_data.txt");
    if (file.is_open()) {
        file >> totalBooks;
        file.ignore();  // Move to the next line
        for (int i = 0; i < totalBooks; i++) {
            getline(file, books[i].title, '|');
            getline(file, books[i].author, '|');
            getline(file, books[i].genre, '|');
            file >> books[i].quantity;
            file.ignore();  // Move to the next line
            file >> books[i].price;
            file.ignore();  // Move to the next line
        }
        file.close();
    } else {
        cerr << "Unable to open file for loading book data.\n";
    }
}


// To exit from program
void exitProgram() {
	
	system("CLS");
	
    cout << "Thanks for Visiting Our Book Store!\n";
    exit(0);
}

